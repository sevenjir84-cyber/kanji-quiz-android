# Kanji Quiz Android

Proyek Android untuk membungkus `kanji_quiz.html` menjadi aplikasi Android WebView.

## Membuat APK melalui GitHub Actions (tanpa memasang Android Studio)

1. Ekstrak ZIP proyek ini.
2. Buat repository baru di GitHub dan unggah seluruh isi folder proyek ke repository tersebut.
3. Buka tab **Actions** pada repository. Jika diminta, izinkan Actions.
4. Pilih workflow **Build Kanji Quiz APK**, lalu tekan **Run workflow**.
5. Tunggu sampai selesai dengan status hijau.
6. Buka hasil workflow dan unduh artifact **KanjiQuiz-debug-apk**.
7. Ekstrak ZIP artifact tersebut. File `app-debug.apk` adalah APK untuk dipasang di Android.

## Membuat APK dengan Android Studio

1. Buka folder proyek ini di Android Studio.
2. Tunggu Gradle Sync selesai.
3. Pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. APK debug biasanya berada di `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan

- HTML kuis disimpan di dalam aplikasi, jadi halaman kuis tidak perlu internet untuk dibuka.
- JavaScript dan DOM storage aktif agar fitur kuis dan `localStorage` bekerja.
- Penyimpanan data aplikasi terpisah dari data browser yang digunakan untuk membuka file HTML.
- APK yang dibuat dengan workflow ini adalah APK debug untuk pemasangan pribadi, bukan rilis Play Store.
- `applicationId` default: `com.example.kanjiquiz`.
